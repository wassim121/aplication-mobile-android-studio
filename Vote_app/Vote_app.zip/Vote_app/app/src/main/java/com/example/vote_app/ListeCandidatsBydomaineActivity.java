package com.example.vote_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ListeCandidatsBydomaineActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        DatabaseHelper dbHelper = new DatabaseHelper(this);

        try {
            Intent intent = getIntent();
            String DOMAIN_Nom = null;

            if (intent != null && intent.hasExtra("DOMAIN_Nom")) {
                DOMAIN_Nom = intent.getStringExtra("DOMAIN_Nom");
            }

            if (DOMAIN_Nom != null) {
                ArrayList<Condidat> candidats = dbHelper.getCandidatesByDomain(DOMAIN_Nom);

                RecyclerView recyclerView = findViewById(R.id.recyclerViewCandidates);
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                CandidateAdapter adapter = new CandidateAdapter(candidats);
                recyclerView.setAdapter(adapter);
            } else {
                showToast("Domain name is null or not provided.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showToast("Error retrieving candidates: " + e.getMessage());
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
